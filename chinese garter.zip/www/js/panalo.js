winGame = {
	create: function (){
		game.physics.startSystem(Phaser.Physics.ARCADE);
		 

                    bg33 = game.add.sprite(0,0, "bg33");
                    bg33.scale.x=.40;
                    bg33.scale.y=1;
                                   	
         menuText = game.add.text (0,0, "Magdiwang ^_^\nScore: "+score, {"fill" : "black"});
		menuText.scale.x =1;
		menuText.scale.y =1;
	
	},

	update: function(){
		
	

   }	
	
}

