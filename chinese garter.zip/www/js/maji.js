menuGame = {
	create: function (){

		  abt = game.add.sprite(0,0, "abt");
                  abt.scale.x=.40;
                  abt.scale.y=1;

	},
	update: function(){
	


	}
}