loseGame = {
	create: function (){
		game.physics.startSystem(Phaser.Physics.ARCADE);
		
      
                    
                    bg2 = game.add.sprite(0,0, "bg2");
                    bg2.scale.x=.40;
                    bg2.scale.y=1;
                                   	
         menuText = game.add.text (0,0, "Game Over\nScore: "+score, {"fill" : "black"});
		menuText.scale.x =1;
		menuText.scale.y =1;
	

	
	},

	update: function(){
		
	

   }	
	
}

